"""
shortcuts for importing blueprints
"""

from .appointments import appointments_bp
from .masters import masters_bp
