"""
Appointments routes group
"""

from .routes import appointments_bp
