"""
Masters routes group
"""

from .routes import masters_bp
